package com.example.cc6flutlabactivity1borbonbsit3a

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
